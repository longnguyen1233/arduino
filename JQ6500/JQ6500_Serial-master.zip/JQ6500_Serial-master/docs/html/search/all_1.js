var searchData=
[
  ['getequalizer_6',['getEqualizer',['../class_j_q6500___serial.html#a8434bee28c17f1416d52b47233b7b02d',1,'JQ6500_Serial']]],
  ['getloopmode_7',['getLoopMode',['../class_j_q6500___serial.html#a664cf9ead4482b9b8aa1f624a9946fb0',1,'JQ6500_Serial']]],
  ['getstatus_8',['getStatus',['../class_j_q6500___serial.html#a26a539cd68ac3b0ce35c8af9dd68d2cb',1,'JQ6500_Serial']]],
  ['getvolume_9',['getVolume',['../class_j_q6500___serial.html#a43c75b0c11ec1fcc1f81173cb0fa2fc4',1,'JQ6500_Serial']]]
];
